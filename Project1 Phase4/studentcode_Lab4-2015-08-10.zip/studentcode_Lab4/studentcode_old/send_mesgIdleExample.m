%Copyright KMel Robotics 2012. Must read KMEL LICENSE.pdf for terms and conditions before use.

 % This is a script that initializes a blank sequence message, adding some
 % paths and performing some IPC functions. Use this at the top of all of
 % your scripts.
 init seqmsg

 % This loop initializes the relevant fields for each quadrotor you are
 % flying. For now we only have one quadrotor.
 for c=1:numquads
 clear seq % clear out previous sequence sent to low level matlab
 seq(1) = seq_default(); % initialize all fields to blank or default

 %just sit and idle
 seq(end).type = 700; % TYPE that determines what happens in the low level code
 seq(end).time = t_inf; % tells the quad to hover until another message is received
 seq(end).resetgains = 1; % tells the onboard controller to prepare for a set of new gains
 seq(end).trpy = [1,0,0,0]; % tells the quad to give a thrust of 1 gram
% and set desired roll, pitch and yaw to 0
 seq(end).drpy = [0,0,0]; % tells the quad to set the derivatives of deisred rpy to 0
 seq(end).onboardkp = [0,0,0]; % sets the p gain of the onboard controller to 0
 seq(end).onboardkd = [0,0,0]; % sets the d gain of the onboard controller to 0
 seq(end).zeroint = 1; % this resets integral control to 0

 seqM(c).seq = seq; % the variable seqM is a struct with metadata about the sequence
 seq_cntM(c) = 1;
 end

 % This packs the message and sends it via IPC.
 % Do not change anything below this point

 ipcm.type = 4;
 ipcm.qn = 1:numquads;
 ipcm.seq = seqM;
ipcm.seqcnt = ones(numquads,1);

sipcm = serialize(ipcm);

ipcAPIPublish(msg name,sipcm);