% MEAM 620 Student Hover code

if (setitM(qn)~=901) %The variable setitM(qn) tracks what type of sequence each quad is in. 
                     %If the quad switches sequences, this if statement will be active.
    setitM(qn)=901;  %This changes setitM(qn) to the current sequence type so that this code only runs once.
    
    %PUT ANY INITIALIZATION HERE
    if isempty(seqM(qn).seq(seq_cntM(qn)).kp) %check for a desired set of kp, set it
        qd{qn}.kp = seqM(qn).seq(seq_cntM(qn)).kp;
    else
        qd{qn}.kp = [10, 10, 15]; %use the default kp[x,y,z]
    end

     if isempty(seqM(qn).seq(seq_cntM(qn)).kd) %check for a desired set of kd, set it
        qd{qn}.kp = seqM(qn).seq(seq_cntM(qn)).kd;%[x,y,z]
     else
        qd{qn}.kd = [5, 5, 7]; %use the default kp [x,y,z]
     %these are just numbers that I made up, you will have to tune your own controller
     end

     if isempty(seqM(qn).seq(seq_cntM(qn)).zoffset) %check for a desired z offset
        qd{qn}.pos_des = qd{qn}.pos + [0; 0; seqM(qn).seq(seq_cntM(qn)).zoffset];
     % add z offset to current position to be your new desired hover position
     end
    
    params = nanoplus();
    t0 = GetUnixTime;%set 0 time the first time this is called.

    %END INTITIALIZATION

end %everything beyond this point runs every control loop iteration

%COMPUTE CONTROL HERE
% Do other stuff for a while
t_now = GetUnixTime - t0;%update time.
[ desired_state ] = trajectory_generator(t_now, qn, path);
qd{qn}.pos_des    = desired_state.pos;
qd{qn}.vel_des    = desired_state.vel;
qd{qn}.acc_des    = desired_state.acc;
qd{qn}.euler_des(3,1)    = desired_state.yaw;
[trpy, drpy] = controller(qd, t_now, qn, params);