function [trpy, drpy] = controller(qd, t, qn, params)
% CONTROLLER quadrotor controller
% The current states are:
% qd{qn}.pos, qd{qn}.vel, qd{qn}.euler = [roll;pitch;yaw], qd{qn}.omega
% The desired states are:
% qd{qn}.pos_des, qd{qn}.vel_des, qd{qn}.acc_des, qd{qn}.yaw_des, qd{qn}.yawdot_des
% Using these current and desired states, you have to compute the desired controls

% =================== Your code goes here ===================
% Current States broken out for ease of use.
rollNow  = qd{qn}.euler(1);
pitchNow = qd{qn}.euler(2);
yawNow   = qd{qn}.euler(3);

%Angular velocity of body with respect to the body axis.
    
% Desired roll, pitch and yaw
angleLimit=30*pi/180;
epLimit = 0.25;
evLimit = 0.2;
offFac =1.1;
kd=zeros(3,1);
kp=zeros(3,1);



%--------- Set Gains -----------%
kp(1:3,1) = qd{qn}.kp(1:3);%[x,y,z]
kd(1:3,1) = qd{qn}.kd(1:3);%[x,y,z]



% Thurst
%F    = 0;
% r_cmd
ep = qd{qn}.pos_des-qd{qn}.pos;
% logic=ep>epLimit;
% ep(logic)=epLimit;   
% logic=ep<-epLimit;
% ep(logic)=-epLimit;
% 
ev = qd{qn}.vel_des-qd{qn}.vel;
% logic=ev>evLimit;
% ev(logic)=evLimit; 
% logic=ev<-evLimit;
% ev(logic)=-evLimit;

rdd_cmd(3,1) = qd{qn}.acc_des(3)+kd(3,1)*(ev(3))+ kp(3,1)*(ep(3));
rdd_cmd(2,1) = qd{qn}.acc_des(2)+kd(2,1)*(ev(2))+ kp(2,1)*(ep(2));
rdd_cmd(1,1) = qd{qn}.acc_des(1)+kd(1,1)*(ev(1))+ kp(1,1)*(ep(1));


F    = params.mass*(params.grav+rdd_cmd(3,1));%    
%hover controller...
%F = params.mass*(kd(3)*qd{qn}.vel(3)+kp(3)*(qd{qn}.pos(3)-qd{qn}.pos_des(3)));
if F<params.minF
    F = params.minF;
end
%Convert force from Newtons to grams.
F=F/params.grav*1000;
%Desired Angles
phi_des = 1/params.grav*(rdd_cmd(1)*sin(yawNow)-...
                        rdd_cmd(2)*cos(yawNow));
theta_des = 1/params.grav*(rdd_cmd(1)*cos(yawNow)-...
                        rdd_cmd(2)*sin(yawNow));

%%error limits on theta
if phi_des>angleLimit
    phi_des=angleLimit;
elseif phi_des<-angleLimit
    phi_des=-angleLimit;
end
if theta_des>angleLimit
    theta_des=angleLimit;
elseif theta_des<-angleLimit
    theta_des=-angleLimit;
end
psi_des = qd{qn}.euler_des(3,1);

% =================== Your code ends here ===================

% Output trpy and drpy as in hardware
trpy = [F, phi_des, theta_des, psi_des];
drpy = [0, 0,       0,         0];

end
