close all;
clear all;
limHover = [-2 -1.4 -1.4 -1 1 2];
limNet   = [-2 3 -2 3 0 4];


load('qdSave_hover.mat')
plot3(qdSave{1}.pos(2:end,1),qdSave{1}.pos(2:end,2),qdSave{1}.pos(2:end,3),'.r');
hold on;
grid on;
plot3(qdSave{1}.pos_des(2:end,1),qdSave{1}.pos_des(2:end,2),qdSave{1}.pos_des(2:end,3),'.b');
title('Hover:3D plot of Actual(red) versus Desired(blue)')
axis(limHover)
xlabel('X Position Meters') % x-axis label
ylabel('Y Position Meters') % y-axis label
zlabel('Z Position Meters') % x-axis label

hold off;

figure
load('qdSave_Multi_hover_disturb.mat')
plot3(qdSave{1}.pos(2:end,1),qdSave{1}.pos(2:end,2),qdSave{1}.pos(2:end,3),'.r');
hold on;
grid on;
plot3(qdSave{1}.pos_des(2:end,1),qdSave{1}.pos_des(2:end,2),qdSave{1}.pos_des(2:end,3),'.b');
title('Hover with Disturbances:3D plot of Actual(blue) versus Desired(red)')
axis(limHover)
xlabel('X Position Meters') % x-axis label
ylabel('Y Position Meters') % y-axis label
zlabel('Z Position Meters') % x-axis label

hold off;


figure
load('qdSave_SingleWP.mat')
plot3(qdSave{1}.pos(2:end,1),qdSave{1}.pos(2:end,2),qdSave{1}.pos(2:end,3),'.r');
hold on;
grid on;
plot3(qdSave{1}.pos_des(2:end,1),qdSave{1}.pos_des(2:end,2),qdSave{1}.pos_des(2:end,3),'.b');
title('Hover with Disturbances:3D plot of Actual(blue) versus Desired(red)')
axis(limNet)
xlabel('X Position Meters') % x-axis label
ylabel('Y Position Meters') % y-axis label
zlabel('Z Position Meters') % x-axis label

hold off;