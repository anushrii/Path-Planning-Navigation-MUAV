close all;
clear all;
load('qdSave_Multi_4.mat')
plot3(qdSave{1}.pos(2:end,1),qdSave{1}.pos(2:end,2),qdSave{1}.pos(2:end,3),'.r');
hold on;
grid on;
plot3(qdSave{1}.pos_des(2:end,1),qdSave{1}.pos_des(2:end,2),qdSave{1}.pos_des(2:end,3),'.b');
title('3D plot of Actual(blue) versus Desired(red)')
axis([-2 6 -2 6 -2 6])
xlabel('X Position Meters') % x-axis label
ylabel('Y Position Meters') % y-axis label
zlabel('Z Position Meters') % x-axis label

hold off;