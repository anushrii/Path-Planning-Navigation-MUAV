close all;
clear all;
load('qdSave_Multi_1.mat')
plot3(qdSave{1}.pos(2:end,1),qdSave{1}.pos(2:end,2),qdSave{1}.pos(2:end,3),'.r');
hold on;
grid on;
plot3(qdSave{1}.pos_des(2:end,1),qdSave{1}.pos_des(2:end,2),qdSave{1}.pos_des(2:end,3),'.b');
title('3D plot of Actual(red) versus Desired(blue)')
axis([-2 3 -2 3 -2 3])
xlabel('X Position Meters') % x-axis label
ylabel('Y Position Meters') % y-axis label
zlabel('Z Position Meters') % z-axis label
hold off;

t = [1:size(qdSave{1}.pos,1)-1].*0.01';
figure
subplot(3,1,1)
plot(t,qdSave{1}.pos_des(2:end,1),'b','LineWidth',2)
hold on;
grid on;
plot(t,qdSave{1}.pos(2:end,1), 'r','LineWidth',2)
hold off;
title('X - position')
ylabel('Position Meters') % x-axis label
xlabel('Time (s)') % y-axis label

subplot(3,1,2)
plot(t,qdSave{1}.pos_des(2:end,2),'b','LineWidth',2)
hold on;
grid on;
plot(t,qdSave{1}.pos(2:end,2), 'r','LineWidth',2)
hold off;
title('Y - position')
ylabel('Position Meters') % x-axis label
xlabel('Time (s)') % y-axis label

subplot(3,1,3)
plot(t,qdSave{1}.pos_des(2:end,3),'b','LineWidth',2)
hold on;
grid on;
plot(t,qdSave{1}.pos(2:end,3), 'r','LineWidth',2)
hold off;
title('Z - position')
ylabel('Position Meters') % x-axis label
xlabel('Time (s)') % y-axis label