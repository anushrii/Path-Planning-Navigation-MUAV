function [ desired_state ] = trajectory_generator(t, qn, path)
% TRAJECTORY_GENERATOR: Turn a Dijkstra or A* path into a trajectory
%
% NOTE: This function would be called with variable number of input
% arguments. In init_script, it will be called with arguments
% trajectory_generator([], [], map, path) and later, in test_trajectory,
% it will be called with only t and qn as arguments, so your code should
% be able to handle that. This can be done by checking the number of
% arguments to the function using the "nargin" variable, check the
% MATLAB documentation for more information.
%
% map: The map structure returned by your load_map function
% path: This is the path returned by your planner (dijkstra function)
%
% desired_state: Contains all the information that is passed to the
% controller, as in phase 2
%
% It is suggested to use "persistent" variables to store map and path
% during the initialization call of trajectory_generator, e.g.
% persistent map0 path0
persistent  path0 times a0 a1 a2 a3 a4 a5;

switch nargin
    case 2
        %idk what to do;
        rungenerate=true;
    case 3
        %map0 = map;
        
        path0 = path;
        times=zeros(size(path0,1),1);
        vscale=2;
            a0 = zeros(size(path0,1)-1,3);
            a1 = zeros(size(path0,1)-1,3);
            a2 = zeros(size(path0,1)-1,3);
            a3 = zeros(size(path0,1)-1,3);
            a4 = zeros(size(path0,1)-1,3);
            a5 = zeros(size(path0,1)-1,3);
        for i=1:(size(path0,1)-1)
            dist=norm(path0(i,:)-path0(i+1,:));
            tduri = nthroot(dist,2)*vscale;
            vel=dist/tduri;
            %%Increase limit after verification. 1.5 is meant to be safe
            %%and slow.
            velmax=1.5;
            if vel>velmax
                vel=velmax;
                tduri=dist/vel;
            end
            times(i+1,1) = tduri+times(i,1);
            t0 = 0;
            tf = times(i+1,1)-times(i,1);
            conditions(:,1) =[path0(i,1); 0; 0; path0(i+1,1); 0; 0];
            conditions(:,2) =[path0(i,2); 0; 0; path0(i+1,2); 0; 0];
            conditions(:,3) =[path0(i,3); 0; 0; path0(i+1,3); 0; 0];

            %%Solve coefficients of polynomial.

            mat = [ 1, t0, t0^2,   t0^3,   t0^4,     t0^5;%, t0^4, t0^5;...
                    0,  1, 2*t0, 3*t0^2, 4*t0^3, 5*t0^4;...
                    0,  0,    2,   6*t0,12*t0^2,20*t0^3;...
                    1, tf, tf^2,   tf^3,   tf^4,   tf^5;...
                    0,  1, 2*tf, 3*tf^2, 4*tf^3, 5*tf^4;...
                    0,  0,    2,   6*tf,12*tf^2,20*tf^3];
            coeff(:,1)=mat\conditions(:,1);
            coeff(:,2)=mat\conditions(:,2);
            coeff(:,3)=mat\conditions(:,3);
                a0(i,1) = coeff(1,1);
                a1(i,1) = coeff(2,1);
                a2(i,1) = coeff(3,1);
                a3(i,1) = coeff(4,1);
                a4(i,1) = coeff(5,1);
                a5(i,1) = coeff(6,1);%
                %
                 a0(i,2) = coeff(1,2);
                a1(i,2) = coeff(2,2);
                a2(i,2) = coeff(3,2);
                a3(i,2) = coeff(4,2);
                a4(i,2) = coeff(5,2);
                a5(i,2) = coeff(6,2);
                %
                a0(i,3) = coeff(1,3);
                a1(i,3) = coeff(2,3);
                a2(i,3) = coeff(3,3);
                a3(i,3) = coeff(4,3);
                a4(i,3) = coeff(5,3);
                a5(i,3) = coeff(6,3);
        end

        rungenerate=false;
%         disp('ran')
        
    otherwise
       rungenerate=false;
end

 
    pos= path0(1,:)';
    vel = [0; 0; 0];
    acc = [0; 0; 0];
    yaw = 0;
    yawdot = 0;
    if rungenerate
        
        timesIndex = find((t>=times)==0);
        if t<times(end,1)
           
        t=t-times(timesIndex(1)-1,1);
        loc=1;
        pos(loc,1)=a0(timesIndex(1)-1,loc)+a1(timesIndex(1)-1,loc)*t+a2(timesIndex(1)-1,loc)*t^2+a3(timesIndex(1)-1,loc)*t^3+...
                a4(timesIndex(1)-1,loc)*t^4+a5(timesIndex(1)-1,loc)*t^5;
           
        loc=2;
        pos(loc,1)=a0(timesIndex(1)-1,loc)+a1(timesIndex(1)-1,loc)*t+a2(timesIndex(1)-1,loc)*t^2+a3(timesIndex(1)-1,loc)*t^3+...
                a4(timesIndex(1)-1,loc)*t^4+a5(timesIndex(1)-1,loc)*t^5;
         loc=3;
        pos(loc,1)=a0(timesIndex(1)-1,loc)+a1(timesIndex(1)-1,loc)*t+a2(timesIndex(1)-1,loc)*t^2+a3(timesIndex(1)-1,loc)*t^3+...
                a4(timesIndex(1)-1,loc)*t^4+a5(timesIndex(1)-1,loc)*t^5;
    %Velocity
        loc=1;
        vel(loc,1)=a1(timesIndex(1)-1,loc)+2*a2(timesIndex(1)-1,loc)*t+3*a3(timesIndex(1)-1,loc)*t^2+...
                4*a4(timesIndex(1)-1,loc)*t^3+5*a5(timesIndex(1)-1,loc)*t^4;
        loc=2;
        vel(loc,1)=a1(timesIndex(1)-1,loc)+2*a2(timesIndex(1)-1,loc)*t+3*a3(timesIndex(1)-1,loc)*t^2+...
                4*a4(timesIndex(1)-1,loc)*t^3+5*a5(timesIndex(1)-1,loc)*t^4;
         loc=3;
        vel(loc,1)=a1(timesIndex(1)-1,loc)+2*a2(timesIndex(1)-1,loc)*t+3*a3(timesIndex(1)-1,loc)*t^2+...
                4*a4(timesIndex(1)-1,loc)*t^3+5*a5(timesIndex(1)-1,loc)*t^4;
     %Acceleration
         loc=1;
        acc(loc,1)=2*a2(timesIndex(1)-1,loc)+6*a3(timesIndex(1)-1,loc)*t+...
                12*a4(timesIndex(1)-1,loc)*t^2+20*a5(timesIndex(1)-1,loc)*t^3;
        loc=2;
        acc(loc,1)=2*a2(timesIndex(1)-1,loc)+6*a3(timesIndex(1)-1,loc)*t+...
                12*a4(timesIndex(1)-1,loc)*t^2+20*a5(timesIndex(1)-1,loc)*t^3;
         loc=3;
        acc(loc,1)=2*a2(timesIndex(1)-1,loc)+6*a3(timesIndex(1)-1,loc)*t+...
                12*a4(timesIndex(1)-1,loc)*t^2+20*a5(timesIndex(1)-1,loc)*t^3;

        else
            pos= path0(end,:);
            vel = [0; 0; 0];
            acc = [0; 0; 0];
            yaw = 0;
            yawdot = 0;
        end
    end




 % =================== Your code ends here ===================

desired_state.pos = pos(:);
desired_state.vel = vel(:);
desired_state.acc = acc(:);
desired_state.euler_des(3,1) = yaw;
desired_state.yawdot = yawdot;
end

