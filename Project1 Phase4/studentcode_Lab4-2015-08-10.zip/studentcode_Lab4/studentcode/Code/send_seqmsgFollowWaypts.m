%Copyright KMel Robotics 2012. Must read KMEL_LICENSE.pdf for terms and conditions before use.

%This is a script that initializes a blank sequence message, adding some 
%paths and performing some IPC functions. Use this at the top of all of 
%your scripts.
init_seqmsg

%This loop initializes the relevant fields for each quadrotor you are
%flying. 
for c=1:numquads
    
    clear seq %clear out previous sequence sent to low level matlab
    seq(1) = seq_default(); %intialize all fields to blank or default

    %just sit and idle
    seq(end).type = 903; %this is the TYPE that determines what happens in the low level code
    seq(end).time = t_inf;%this tells the quad to hover until another message is received
    
    %PUT OTHER FIELDS HERE
    %%----------   Set Gains and Offset -----------
    load test_waypts_3
    
    params = nanoplus();
    seq(end).kp = params.kp; % Set proportional gains of hover controller kp[x,y,z]
    seq(end).kd = params.kd;% Set derivative gains of hover controller kd[x,y,z]
    seq(end).zoffset = 0.0;  % Set the offset in z direction. this will be added to the landing position.
    seq(end).waypoint = waypts';
    %END OTHER FIELDS HERE
    
    seqM(c).seq = seq; %the variable seqM is a struct with metadata about the sequence
    seq_cntM(c) = 1;
end

%This packs the message and sends it via IPC. Do not change this.
ipcm.type = 4;
ipcm.qn = 1:numquads;
ipcm.seq = seqM;
ipcm.seqcnt = ones(numquads,1);

sipcm = serialize(ipcm);

ipcAPIPublish(msg_name,sipcm);



