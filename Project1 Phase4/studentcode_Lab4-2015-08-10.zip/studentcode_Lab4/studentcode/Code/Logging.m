%%Logging Code 


        %Desired
        qdSave{qn}.euler_des= [qdSave{qn}.euler_des;qd{qn}.euler_des'];
        qdSave{qn}.pos_des = [qdSave{qn}.pos_des;qd{qn}.pos_des'];
        qdSave{qn}.vel_des = [qdSave{qn}.vel_des;qd{qn}.vel_des'];
        %Actual
        qdSave{qn}.euler = [qdSave{qn}.euler;qd{qn}.euler'];
        qdSave{qn}.pos = [qdSave{qn}.pos ;qd{qn}.pos'];
        qdSave{qn}.vel= [qdSave{qn}.vel;qd{qn}.vel'];
%         qdSave{qn}.ep(:,indexSave) = ep;
%         qdSave{qn}.ev(:,indexSave) = ev;
%         qdSave{qn}.theta_des(1,indexSave) = theta_des;
%         qdSave{qn}.phi_des(1,indexSave) = phi_des;


